const handler = require('./src/handler');

exports.handler = async (event) => handler(event);
