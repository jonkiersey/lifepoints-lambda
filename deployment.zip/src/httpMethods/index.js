const GET = require('./GET');
const OPTIONS = require('./OPTIONS');
const PUT = require('./PUT');

module.exports = { GET, OPTIONS, PUT };
